# FFPE_mousebrain_explorer
Spatial transcriptomics data of coronal sections from mouse brain generated from FFPE and fresh frozen tissue. 
